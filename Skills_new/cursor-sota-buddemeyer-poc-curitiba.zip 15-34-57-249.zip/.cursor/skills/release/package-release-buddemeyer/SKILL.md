---
name: package-release-buddemeyer
description: Preparar build e release reproduzível do supervisório Buddemeyer com versionamento, manifesto, dependências, testes, implantação gradual e rollback. Use para empacotar ou planejar uma versão; nunca implante na célula sem autorização explícita.
---

# Empacotar e liberar o supervisório

Separe preparação do artefato, validação, aprovação e implantação. Esta skill pode produzir e verificar um pacote; não autoriza deploy, transferência ao CLP/robô ou mudança de produção.

## Baseline

- Descubra plataforma alvo, entrypoint, gerenciador de dependências, lockfile, build atual e processo de atualização.
- Registre versão do aplicativo, commit, Python/Qt, dependências, modelo/checkpoint, schema de configuração, calibração compatível e revisão esperada das interfaces/CLP.
- Identifique arquivos gerados, segredos, dados operacionais e configurações que nunca devem entrar no artefato.

## Pipeline recomendado

1. Comece em uma árvore Git limpa e commit identificável.
2. Execute lint, análise estática e testes existentes; registre comandos e resultados.
3. Construa em ambiente limpo usando versões travadas e processo documentado.
4. Gere um manifesto com versão, commit, plataforma, dependências, componentes opcionais e hashes dos artefatos críticos.
5. Produza checksum e assinatura somente se a infraestrutura real suportar verificação confiável.
6. Execute smoke test do pacote instalado: abrir, validar configuração, iniciar/parar, operar com simuladores e encerrar sem recursos residuais.
7. Compare o conteúdo final com uma allowlist; exclua credenciais, `.env`, dumps, PCAPs, imagens de produção e caches.

## Plano de liberação

- Defina pré-condições, backup, responsável, janela, etapas, observabilidade e critério de abortar.
- Faça progressão bancada → integração simulada → HIL → piloto controlado → produção, conforme aprovação local.
- O rollback deve restaurar binário, configuração/schema, modelo e calibração como conjunto compatível.
- Após liberar, observe tempo de ciclo, erro, reconexão, freshness, recursos e restart por período aprovado.

## Saída

Entregue artefato/manifesto, origem reproduzível, testes e evidências, matriz de compatibilidade, runbook de implantação, critérios go/no-go e rollback testado. Marque claramente qualquer etapa não executada. Não execute `deploy`, `sync`, `transfer`, mudança online ou reinício industrial sem solicitação e autorização explícitas.

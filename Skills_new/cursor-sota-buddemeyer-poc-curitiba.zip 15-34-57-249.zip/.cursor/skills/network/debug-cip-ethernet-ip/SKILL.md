---
name: debug-cip-ethernet-ip
description: Diagnosticar perda, timeout, reconexão, dado obsoleto ou inconsistente em CIP sobre EtherNet/IP entre aplicação, Omron NX102 e dispositivos industriais. Use quando houver evidência de comunicação; não use para todo erro do NX102.
---

# Diagnóstico CIP e EtherNet/IP

Analise de modo não intrusivo primeiro. Diferencie aplicação, CIP, EtherNet/IP, IP/Ethernet, endpoint e lógica que consome os dados.

## Contexto mínimo

- origem/destino, modelo/firmware, IP, porta física e caminho CIP;
- I/O implícito/tag data link ou mensagem explícita;
- produtor/consumidor, tamanho, RPI/intervalo e timeout;
- unicast/multicast, switches, VLAN, redundância e relógios;
- status geral/estendido, contador, timestamp e frequência.

Masque credenciais e revise PCAPs/dumps antes de compartilhá-los.

## Isolamento por camada

1. **Aplicação:** freshness, sequência/heartbeat, qualidade, thread/loop e resposta a dado obsoleto.
2. **CIP:** conexão, status geral/estendido, caminho, instância/assembly/tag, limites e reconexões.
3. **Rede:** perda, jitter, IP duplicado, link flap, erros/descartes de porta, multicast e filas.
4. **Carga:** RPI, conexões, pacotes e carga do controlador/dispositivo, comparados aos limites documentados da versão real.
5. **Físico:** cabo, blindagem/aterramento, conectores, alimentação e interferência, com equipe habilitada.

Não conclua “rede” apenas por timeout. Diga qual observação distingue atraso de lógica, falha do endpoint, perda de pacote ou incompatibilidade.

## Captura, mudança e saída

Prefira espelhamento de porta/TAP e estatísticas do switch. Defina filtro, duração e horário, correlacionando timestamps. Não faça scan agressivo, flood, fuzzing ou carga em produção. RPI, QoS, IGMP, topologia e firmware só mudam após baseline, autorização e janela.

Entregue topologia, conexão afetada, linha do tempo, baseline versus falha, interpretação do status, hipótese, teste discriminante, correção reversível e validação sob carga representativa.


---
name: validate-pick-place-cycle
description: Analisar ou implementar o ciclo ponta a ponta de pick-and-place, handshake aplicação–NX102–robô e FSM ACK/Pick/Place/Complete. Use para estados presos, comandos duplicados, pulsos perdidos, timeout ou coordenação do ciclo.
---

# Validar o ciclo de pick-and-place

Trate cada ciclo como uma transação identificável. Reconstrua o contrato real antes de editar: produtor/consumidor de cada sinal, nível ou pulso, condição de entrada/saída, timeout, ACK, erro, cancelamento e comportamento após reconexão/restart.

## Verificações

1. Desenhe a FSM observada e compare com `docs/project/INTERFACES_AND_STATE_MACHINE.md`.
2. Garanta um `cycle_id` ou contador correlacionável entre detecção, coordenada, pick, place e conclusão.
3. Verifique que cada comando tem ACK inequívoco e que repetição não executa movimento físico duplicado.
4. Rejeite comando, coordenada ou detecção obsoletos por estado, idade e identidade do ciclo.
5. Procure transições impossíveis, estado sem saída, espera sem timeout, race, escrita concorrente, pulso curto e recuperação parcial.
6. Defina transições de erro/cancelamento e retorno seguro a `Idle` sem pular intertravamentos.
7. Cubra happy path, ausência de peça, falha de visão, perda de comunicação, recusa do robô, timeout, restart em cada estado e repetição do ACK.

## Mudança e saída

Faça alterações pequenas e preserve compatibilidade de interface. Não movimente robô, force I/O ou altere safety sem autorização e validação local.

Entregue diagrama/estado atual, invariantes, falha encontrada, mudança mínima, testes por transição, evidência esperada, rollback e observação em ciclos representativos.


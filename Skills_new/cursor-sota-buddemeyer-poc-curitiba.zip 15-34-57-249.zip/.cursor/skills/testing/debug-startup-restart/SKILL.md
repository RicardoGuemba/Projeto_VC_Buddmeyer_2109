---
name: debug-startup-restart
description: Diagnosticar e testar falhas que aparecem ao parar e reiniciar o supervisório, preditor ou integração do POC, embora a primeira inicialização funcione. Use para recursos não liberados, estado residual, threads, portas, câmera, modelo ou handshake preso.
---

# Diagnóstico de inicialização e reinicialização

Compare primeira inicialização, parada e segunda inicialização como três fases observáveis. Não aceite “reiniciar resolve” sem localizar o recurso ou estado residual.

## Investigação

1. Reproduza com comando, versão, configuração e sequência exatos; preserve logs completos das duas inicializações.
2. Liste recursos adquiridos e liberados: câmera, socket/CIP, porta, thread/processo, executor, arquivo, banco, GPU/CPU, modelo e registradores de callback.
3. Verifique ordem e idempotência de `start`, `stop`, `close`, `join`, cancelamento e destrutores/context managers.
4. Procure singleton/global residual, flag de parada não reinicializada, fila antiga, thread zombie, porta ocupada, callback duplicado, sessão expirada e estado da FSM não resetado.
5. Confirme que `stop` aguarda encerramento com timeout finito e que falha de limpeza fica visível.
6. Teste restart em `Idle` e em cada estado relevante, além de dependência indisponível, reconexão e ciclo interrompido.

## Smoke test mínimo

- processo inicia e fica pronto;
- câmera/modelo e comunicação ficam saudáveis;
- um ciclo controlado conclui;
- parada ordenada libera recursos;
- segunda inicialização fica pronta;
- novo ciclo conclui sem duplicidade nem dado antigo;
- repetir a sequência várias vezes e observar handles, threads, memória e conexões.

## Saída

Entregue reprodução, diferença entre primeira/segunda execução, recurso/estado causal, correção mínima, teste automatizado quando possível, rollback e evidência de múltiplos ciclos de restart.


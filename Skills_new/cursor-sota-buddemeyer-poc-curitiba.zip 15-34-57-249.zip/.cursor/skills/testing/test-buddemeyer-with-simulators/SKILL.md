---
name: test-buddemeyer-with-simulators
description: Projetar e executar testes determinísticos do supervisório e ciclo Buddemeyer com fakes, simuladores, replay e injeção de falhas para câmera, visão, NX102/CIP e robô. Use para validar mudanças sem conectar ao hardware real.
---

# Testar o POC com simuladores

Crie uma fronteira clara entre lógica e hardware. O objetivo é obter feedback repetível no desenvolvimento sem afirmar que simulação substitui bancada, HIL, comissionamento ou validação de safety.

## Descoberta

1. Localize as interfaces reais usadas por câmera, preditor, relógio, CLP/CIP, robô, persistência e UI.
2. Identifique quais efeitos são observáveis: mensagens, sinais, estados, coordenadas, alarmes, logs e arquivos.
3. Reuse fixtures e frameworks existentes. Não crie uma segunda infraestrutura paralela sem necessidade.

## Desenho dos doubles

- Prefira protocolos/interfaces pequenas e injeção de dependência a monkeypatch global.
- Um fake deve reproduzir o contrato, não detalhes internos do fornecedor.
- Controle relógio, aleatoriedade, latência e ordem de eventos para eliminar testes flakey.
- Modele freshness, `cycle_id`, ACK, timeout, desconexão, reconexão, erro e cancelamento.
- Nunca use por padrão IP, credencial, tag ou endpoint de produção. A configuração de teste deve falhar de forma segura se um destino real aparecer.

## Pirâmide de validação

1. **Unidade:** transformação, seleção, validação, FSM e políticas de retry/timeout.
2. **Componente Qt:** sinais, slots, modelo de apresentação, lifecycle e restart.
3. **Integração simulada:** aplicação completa com câmera, NX102/CIP e robô falsos.
4. **Contrato:** adaptador real contra uma implementação de referência ou sandbox autorizado.
5. **HIL:** etapa separada, com plano, responsável local, permissivos, janela e critérios aprovados.

## Cenários mínimos

- ciclo nominal e nenhum alvo;
- múltiplos alvos, baixa confiança e coordenada inválida;
- ACK atrasado, duplicado, fora de ordem ou ausente;
- dado obsoleto, perda e retorno de conexão;
- recusa/erro do robô sem repetição indevida de movimento;
- Stop/Start em estados relevantes;
- encerramento durante trabalho assíncrono;
- migração ou receita incompatível.

Use record/replay apenas com dados sanitizados, versão e origem conhecidas. Evite snapshots frágeis de detalhes irrelevantes; teste invariantes e resultados observáveis.

## Saída

Entregue matriz requisito→teste, arquitetura dos simuladores, comandos exatos, resultados, cobertura relevante, falhas conhecidas e o que ainda exige HIL. Um teste verde não autoriza conexão ou movimento físico.

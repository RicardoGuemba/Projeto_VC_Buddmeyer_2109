---
name: validate-camera-robot-calibration
description: Validar calibração e transformação de coordenadas entre câmera, imagem, plano de trabalho e robô no POC de Curitiba. Use para erro pixel–milímetro, offset, escala, orientação, ponto de pega ou mudança mecânica/câmera.
---

# Validar calibração câmera–robô

Não trate “pixel para milímetro” como escala única até confirmar a geometria. Identifique o modelo adotado: escala/offset, transformação afim, homografia planar ou calibração completa com extrínsecos.

## Entradas

- resolução/crop e parâmetros da câmera;
- posição, altura, foco e fixação;
- referencial da imagem, mesa, robô, ferramenta e ponto de pega;
- pares de pontos de calibração, unidade e método de ajuste;
- versão da calibração e condições mecânicas/ópticas;
- tolerância operacional aprovada.

## Validação

1. Confirme convenções de eixos, origem, sinal, unidade, rotação e ordem das transformações.
2. Separe pontos de ajuste e validação; nunca avalie apenas nos pontos usados para calibrar.
3. Calcule resíduos por ponto, RMSE, percentis e erro máximo em milímetros; visualize o erro por região.
4. Teste centro, cantos, bordas e alturas/planos realmente usados. Se o objeto varia em Z, quantifique o erro de uma hipótese planar.
5. Verifique distorção de lente, alteração de resolução/crop, movimento da câmera, folga, TCP/ferramenta e offset do efetor.
6. Versione matriz, dados, timestamp, responsável, configuração e código que consome a calibração.
7. Defina gatilhos de recalibração: câmera/poste movido, foco/resolução alterados, ferramenta/TCP trocados ou erro de validação excedido.

## Saída

Entregue modelo matemático observado, dados válidos, métricas e mapa de erro, regiões não confiáveis, causa provável, correção, teste físico controlado, tolerância aprovada e rollback para a calibração anterior.


---
name: validate-vision-inference
description: "Diagnosticar e aprimorar a inferência de visão do pick-and-place: aquisição, preprocessamento, modelo, checkpoint, detecção, seleção de embalagem, confiança, latência e qualidade da coordenada. Use quando o erro nasce da câmera ou preditor."
---

# Validar visão e inferência

Separe aquisição, transformação da imagem, carregamento do modelo, inferência, pós-processamento, seleção do alvo e publicação da coordenada.

## Baseline

Registre câmera/resolução, distância e iluminação, versão/hash do modelo e checkpoint, dispositivo de inferência, dependências, classes, limiar, NMS/pós-processamento, regra de seleção, latência e conjunto de teste representativo.

## Diagnóstico

1. Confirme que os artefatos carregados pertencem ao mesmo checkpoint e configuração.
2. Valide orientação, resolução, espaço de cor, normalização, resize/letterbox e mapeamento de coordenadas ao frame original.
3. Compare detecção bruta, pós-processamento e alvo final; não confunda erro do modelo com regra de seleção.
4. Meça precisão/recall e erro relevante ao processo por cenário: variedade, posição, oclusão, iluminação e objetos semelhantes.
5. Verifique validade temporal da imagem e impeça reuso de frame/detecção antiga após restart ou reconexão.
6. Preserve imagem, predição, confiança, bbox/máscara, timestamp, `cycle_id` e motivo de rejeição para rastreabilidade.
7. Teste ausência de alvo, múltiplos alvos, baixa confiança, borda da cena, frame corrompido, câmera indisponível e retomada.

## Saída

Entregue estágio causal, evidências, amostras reprodutíveis, métricas antes/depois, alteração proposta, impacto operacional, teste offline, rollback e critério de liberação. Mudança de modelo não substitui validação câmera–robô.

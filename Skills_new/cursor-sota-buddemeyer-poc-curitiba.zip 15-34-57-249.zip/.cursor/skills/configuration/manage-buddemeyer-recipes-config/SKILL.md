---
name: manage-buddemeyer-recipes-config
description: Criar, alterar, validar, migrar e versionar receitas e configurações do supervisório Buddemeyer, incluindo unidades, limites, persistência atômica, compatibilidade e rollback. Use quando o comportamento variar por parâmetros ou produto.
---

# Gerenciar receitas e configuração

Trate configuração como uma interface versionada. Descubra formatos, leitores, escritores, defaults, precedência e consumidores atuais antes de mudar qualquer campo.

## Modelo e validação

1. Defina schema explícito com versão, tipos, obrigatoriedade, faixa, enumeração e unidade.
2. Valide na fronteira antes de publicar a configuração ao domínio ou hardware.
3. Não use valor default silencioso para um parâmetro que possa afetar movimento, qualidade ou integridade do ciclo.
4. Normalize unidades e referenciais; não misture pixel, milímetro, grau, segundo e milissegundo sem conversão nomeada.
5. Separe receita de produto, configuração de ambiente, calibração, segredo e estado transitório.
6. Preserve provenance: identificador, revisão, autor/aprovador quando disponível, timestamp e motivo da alteração.

Use a biblioteca de schema já adotada pelo repositório. Não imponha Pydantic, dataclasses ou outro framework sem avaliar compatibilidade.

## Persistência e concorrência

- Grave em arquivo temporário validado e substitua de forma atômica quando o sistema de arquivos permitir.
- Preserve backup da última versão válida e teste recuperação após escrita interrompida.
- Não altere a receita ativa no meio de um ciclo sem contrato explícito. Use snapshot por `cycle_id` ou aplique a nova revisão somente em estado seguro.
- Detecte edição concorrente por revisão/hash quando mais de um ator puder gravar.
- Nunca armazene senha, token ou chave junto com receitas versionadas.

## Migração e compatibilidade

1. Declare versão de origem e destino.
2. Faça migração determinística, idempotente e testável em cópias dos dados.
3. Preserve uma rota de downgrade ou backup restaurável.
4. Rejeite versões futuras/incompatíveis com mensagem acionável.
5. Valide amostras reais sanitizadas e casos de borda antes da liberação.

## Saída

Entregue schema antes/depois, consumidores afetados, estratégia de migração, testes de validade/limites/interrupção/rollback, exemplo sem segredos e instruções de recuperação. Combine com `validate-camera-robot-calibration` quando parâmetros forem geométricos e com `package-release-buddemeyer` quando houver mudança de schema na distribuição.

---
name: harden-buddemeyer-24x7
description: Avaliar preventivamente confiabilidade, observabilidade, recuperação, deploy e operação contínua 24x7 do POC Buddemeyer. Use para hardening e prevenção; para uma parada ativa de causa desconhecida, use incident-triage-buddemeyer.
---

# Hardening Buddemeyer 24x7

Operação 24x7 exige falhas detectáveis, degradação segura e recuperação ensaiada; não significa prometer ausência total de falhas.

## Baseline

Descubra serviços e dependências; interfaces de visão, NX102, rede, robô, banco/arquivos e IHM; SLOs, RTO/RPO; volume e ciclo nominal/pico; janelas; modos históricos; MTBF/MTTR; pontos únicos; deploy, rollback, backup e restauração.

## Avaliação

1. Modele o fluxo ponta a ponta e os pontos únicos de falha.
2. Revise timeouts finitos, cancelamento, retry limitado com backoff/jitter, idempotência, circuit breaker e filas/memória limitadas.
3. Impeça que reconexões reutilizem coordenadas, detecções ou dados CIP antigos. Use qualidade, timestamp, contador e estado explícito.
4. Defina estado seguro para perda de câmera, modelo, CLP, robô, rede, banco, disco, relógio e energia.
5. Separe liveness, readiness e saúde de dependências; evite restart infinito que esconda defeito.
6. Estruture logs com timestamp, correlação de ciclo/lote, componente, estado anterior/novo e erro original, sem segredos.
7. Meça disponibilidade, latência, backlog, reconexões, idade do dado, timeouts, perda, recursos e tempo de ciclo.
8. Planeje implantação gradual, rollback testado e observação que cubra picos, trocas de turno e receitas.
9. Teste recuperação em bancada: processo morto, dependência lenta/indisponível, link interrompido, dado inválido, disco cheio e reinício ordenado.

## Entregáveis

Produza matriz de riscos com evidência/proprietário, backlog priorizado por risco–esforço–reversibilidade, mudanças pequenas, testes, rollback, dashboards/alertas e runbook. Não invente SLOs: proponha-os para aprovação.


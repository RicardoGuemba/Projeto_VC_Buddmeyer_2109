---
name: debug-nx102
description: Diagnosticar eventos, tarefas, watchdogs, warm/cold start, memória, I/O, EtherCAT, lógica e máquinas de estado no Omron NX102/Sysmac. Use quando a evidência apontar para o controlador; não use como diagnóstico genérico de toda a célula.
---

# Diagnóstico do Omron NX102

Use como autoridade os manuais correspondentes ao modelo, unit version, firmware e versão do Sysmac Studio confirmados no projeto.

## Entradas mínimas

- modelo completo, unit version e firmware do NX102;
- versão do Sysmac Studio e revisão do projeto implantado;
- modo/estado atual, períodos e prioridades das tarefas;
- módulos NX, dispositivos EtherCAT e conexões EtherNet/IP envolvidos;
- código completo do evento, severidade, timestamp e contexto;
- estado da sequência antes e depois da falha.

Se faltarem artefatos, peça exportações, capturas ou relatórios somente leitura. Não solicite credenciais.

## Diagnóstico

1. Correlacione o primeiro evento causal; o último alarme pode ser consequência.
2. Verifique mudança de modo, reinício, watchdog, exceção/saturação de tarefa e pico de execução.
3. Revise inicialização, retenção e estados após warm/cold start.
4. Procure espera sem timeout, pulso perdido, corrida entre tarefas, escrita múltipla e tratamento incompleto de `Done`, `Busy`, `Error` e `ErrorID`.
5. Verifique a FSM e o handshake com aplicação/robô, incluindo ACK, Pick, Place, Complete, timeout, repetição, idempotência e recuperação.
6. Diferencie CPU, barramento NX, EtherCAT, EtherNet/IP, dispositivo e lógica usando evidência específica de cada camada.
7. Compare configuração offline/online somente em modo seguro. Divergência é evidência, não autorização para sincronizar.

## Limites e saída

Não transfira projeto, altere modo, force variável, limpe erro, reinicie, ajuste relógio ou mude parâmetro online sem autorização explícita. Não modifique safety nem sugira bypass.

Informe evidências, hipótese causal, tarefa/trecho afetado, teste de confirmação, correção mínima, rollback e critérios mensuráveis de estabilidade.

Para o contrato da sequência, consulte `docs/project/INTERFACES_AND_STATE_MACHINE.md`.


---
name: customize-buddemeyer-supervisory
description: Planejar e implementar novas features ou customizações funcionais no supervisório Buddemeyer, preservando contratos, arquitetura, segurança industrial, testes e rollback. Use quando o pedido alterar comportamento do aplicativo e não for apenas diagnóstico.
---

# Customizar o supervisório Buddemeyer

Conduza a mudança como engenharia de produto industrial, não como edição isolada de código. Descubra primeiro a arquitetura e os contratos reais do repositório; não invente caminhos, bibliotecas, tags ou interfaces.

## Enquadrar a solicitação

1. Reescreva o resultado operacional desejado em uma frase.
2. Defina critérios de aceite observáveis, casos de erro, não objetivos e compatibilidade necessária.
3. Identifique usuários, modos da célula, estados da FSM e dependências afetadas.
4. Separe fatos confirmados, inferências e perguntas bloqueantes. Se a mudança puder produzir movimento físico ou alterar safety, pare e peça autorização e validação local.

## Descobrir antes de editar

- Consulte `docs/project/POC_CURITIBA_CONTEXT.md` e `docs/project/INTERFACES_AND_STATE_MACHINE.md`.
- Localize entrypoints, classes, chamadores, interfaces, configuração, testes, logs e processo de empacotamento.
- Trace o fluxo atual de UI → aplicação → domínio/FSM → adaptadores de câmera, visão, CLP e robô.
- Verifique a branch, alterações locais e convenções do projeto. Preserve mudanças não relacionadas.
- Produza um mapa de impacto com arquivos e contratos que realmente serão alterados.

## Planejar e implementar

1. Comece em modo de planejamento e apresente a menor mudança reversível que atende aos critérios.
2. Preserve a separação entre apresentação, casos de uso, domínio/FSM e adaptadores de hardware.
3. Mantenha compatibilidade de sinais, dados, receitas e estados ou descreva uma migração explícita.
4. Prefira interfaces estreitas, tipos claros, timeout finito, cancelamento, idempotência e dados com identidade/validade.
5. Use feature flag apenas quando existir estratégia real de remoção e rollback; não esconda código morto.
6. Registre erros com contexto, sem credenciais, e mantenha correlação por `cycle_id` quando aplicável.
7. Faça alterações pequenas e revisáveis. Não refatore áreas não necessárias à feature.

Combine esta skill com `develop-pyside6-supervisory-ui` para telas e interação Qt, `test-buddemeyer-with-simulators` para validação offline, `manage-buddemeyer-recipes-config` para configuração/receitas e `validate-pick-place-cycle` para mudanças na sequência industrial.

## Verificação e entrega

- Crie ou atualize testes que falham antes e passam depois da implementação.
- Execute primeiro testes unitários e simulados; HIL e produção são etapas separadas e autorizadas.
- Teste happy path, entradas inválidas, timeout, cancelamento, restart e regressões relevantes.
- Solicite revisão independente ao subagente `industrial-change-verifier` após concluir a implementação.
- Entregue: resumo, arquivos alterados, decisão arquitetural, testes executados e resultados, riscos residuais, passos de validação local e rollback.

Não declare a mudança pronta quando testes essenciais não puderem ser executados. Marque claramente `não verificado` e diga o que falta.

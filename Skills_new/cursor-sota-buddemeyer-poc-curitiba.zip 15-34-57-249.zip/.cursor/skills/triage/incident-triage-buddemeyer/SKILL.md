---
name: incident-triage-buddemeyer
description: Triar paradas, intermitências, alarmes ou comportamento anormal no POC Buddemeyer quando a causa ainda pode estar na aplicação, visão, calibração, NX102, EtherNet/IP, robô ou equipamento de campo.
---

# Triagem de incidentes Buddemeyer

Use esta skill como porta de entrada quando o domínio causal ainda não estiver demonstrado. Preserve a segurança da máquina e procure uma hipótese testável, não um culpado prematuro.

## Fluxo

1. Registre início e fim do sintoma, turno, lote/receita, modo, impacto, último ciclo bom e última mudança conhecida.
2. Normalize fuso e relógio de aplicação, câmera, IHM, NX102, robô, switches e servidor.
3. Colete evidências somente leitura: logs da aplicação, eventos do Sysmac, estados da FSM, contadores/heartbeat, diagnósticos de rede, métricas do host e alterações recentes no Git.
4. Separe o domínio provável: visão, transformação de coordenadas, aplicação/supervisório, NX102, CIP/EtherNet/IP, robô/plataforma, infraestrutura ou operação.
5. Reproduza fora de produção quando possível e reduza ao menor caso que mantém o sintoma.
6. Formule no máximo três hipóteses. Para cada uma, informe evidência favorável, evidência contrária e teste discriminante de baixo risco.
7. Só proponha mudança após identificar um mecanismo causal plausível. Inclua rollback, critério mensurável e período de observação.
8. Depois de estabilizar, registre ações de prevenção, detecção e RCA.

## Limites

- Não altere lógica, estado do CLP, saídas, intertravamentos, safety, firmware ou rede sem autorização explícita e janela aprovada.
- Nunca force I/O nem trate reinicialização como correção definitiva.
- Se houver risco a pessoas, produto ou equipamento, interrompa a investigação remota e solicite o responsável local.

## Saída

Entregue impacto e estado atual, linha do tempo, evidências versus inferências, hipóteses ordenadas, próximo teste seguro, mitigação temporária, correção/rollback e itens de acompanhamento. Marque ausências como `não verificado`.

Consulte `docs/project/POC_CURITIBA_CONTEXT.md` para o contexto vigente e use uma skill especializada quando a camada causal estiver delimitada.


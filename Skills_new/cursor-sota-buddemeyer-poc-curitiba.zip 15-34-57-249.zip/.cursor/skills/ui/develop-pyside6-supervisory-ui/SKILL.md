---
name: develop-pyside6-supervisory-ui
description: Criar ou customizar telas, widgets, diálogos, sinais, slots, threads, timers e estados de UI em supervisórios PySide6/Qt da Buddemeyer. Use para mudanças visuais ou de interação; preserve o event loop e isole hardware da UI.
---

# Desenvolver a UI PySide6 do supervisório

Antes de editar, confirme que o projeto realmente usa PySide6, sua versão e a forma de construção das telas (`.ui`, código Python ou QML). Preserve o padrão já adotado e não edite arquivos gerados quando existir uma fonte correspondente.

## Arquitetura esperada

- A camada de apresentação exibe estado e traduz ações do usuário em intenções.
- Casos de uso coordenam operações; domínio/FSM decide transições; adaptadores encapsulam câmera, visão, CLP, robô, persistência e relógio.
- Widgets não fazem I/O industrial diretamente e não contêm regras de negócio críticas.
- O estado exibido tem fonte única, transições explícitas e tratamento de estados `loading`, vazio, degradado e erro.

## Event loop, concorrência e ciclo de vida

1. Nunca bloqueie a thread da UI com aquisição, inferência, rede, espera ativa ou `sleep`.
2. Use `Signal`/`Slot` com assinaturas claras. Atualizações de widgets devem ocorrer na thread da UI por conexões apropriadas.
3. Para trabalho longo, use o padrão de worker compatível com o projeto e defina ownership, cancelamento, timeout e limpeza determinística.
4. Pare timers, desconecte callbacks, aguarde threads e libere câmera/sockets no fluxo de encerramento.
5. Garanta que `start`, `stop` e `close` sejam idempotentes e funcionem em reinicializações repetidas.
6. Evite múltiplas conexões acidentais de sinais e callbacks depois de reabrir uma tela.

## UX industrial

- Diferencie comando solicitado, comando aceito, operação em curso, conclusão e falha.
- Não apresente dado antigo como atual; mostre qualidade, timestamp ou indicação de indisponibilidade quando relevante.
- Ações perigosas exigem confirmação, estado habilitado coerente e autorização definida pelo sistema real.
- Mensagens devem orientar o operador sem esconder o erro original; use termos e unidades aprovados.
- Teclado, foco, contraste, dimensionamento e telas alvo devem ser verificados no ambiente real.

## Testes

- Teste lógica de apresentação sem hardware por meio de fakes/adaptadores.
- Teste sinais e slots com `QSignalSpy` ou ferramenta equivalente já adotada.
- Cubra abertura/fechamento, estados, validação de campos, operação assíncrona, cancelamento e múltiplos ciclos de Start/Stop.
- Não introduza uma nova biblioteca de testes se a pilha atual já resolver o problema.

## Saída

Informe fluxo de UI antes/depois, responsabilidades por camada, política de thread e limpeza, testes realizados, capturas ou passos de inspeção visual, limitações, risco e rollback. Use `test-buddemeyer-with-simulators` para validar interações sem endpoints reais.

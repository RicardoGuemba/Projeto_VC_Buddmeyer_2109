#!/usr/bin/env python3
"""Perform fast, dependency-free syntax checks after an Agent file edit."""

from __future__ import annotations

import ast
import json
from pathlib import Path
import sys

try:
    import tomllib
except ModuleNotFoundError:  # Python < 3.11: TOML validation is skipped.
    tomllib = None


def within_workspace(path: Path, roots: list) -> bool:
    for root in roots:
        try:
            path.relative_to(Path(root).resolve())
            return True
        except ValueError:
            continue
    return not roots


def validate_frontmatter(path: Path, text: str) -> None:
    lines = text.splitlines()
    if not lines or lines[0].strip() != "---":
        raise ValueError("frontmatter YAML inicial ausente")
    try:
        end = next(index for index, line in enumerate(lines[1:], start=1) if line.strip() == "---")
    except StopIteration as exc:
        raise ValueError("frontmatter YAML não foi fechado") from exc
    header = "\n".join(lines[1:end])
    if path.name == "SKILL.md" and ("name:" not in header or "description:" not in header):
        raise ValueError("SKILL.md precisa declarar name e description")
    if path.suffix == ".mdc" and "alwaysApply:" not in header:
        raise ValueError("rule .mdc precisa declarar alwaysApply")


def validate(path: Path) -> None:
    raw = path.read_bytes()
    if path.suffix == ".py":
        ast.parse(raw.decode("utf-8"), filename=str(path))
    elif path.suffix == ".json":
        json.loads(raw.decode("utf-8"))
    elif path.suffix == ".toml" and tomllib is not None:
        tomllib.loads(raw.decode("utf-8"))
    elif path.name == "SKILL.md" or path.suffix == ".mdc":
        validate_frontmatter(path, raw.decode("utf-8"))


def main() -> int:
    try:
        payload = json.load(sys.stdin)
        path_value = payload.get("file_path")
        if not isinstance(path_value, str):
            raise ValueError("file_path ausente")
        path = Path(path_value).resolve()
        roots = [str(item) for item in payload.get("workspace_roots", []) if isinstance(item, str)]
        if not within_workspace(path, roots):
            raise ValueError("arquivo editado está fora das raízes do workspace")
        if path.exists() and path.is_file():
            validate(path)
    except (OSError, UnicodeError, SyntaxError, ValueError, json.JSONDecodeError) as exc:
        print(f"Validação pós-edição falhou: {exc}", file=sys.stderr)
        print("{}")
        return 2

    print("{}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

#!/usr/bin/env python3
"""Ask for human approval before destructive or industrial state-changing commands.

This is an advisory development guard. It is not a machine-safety function.
"""

from __future__ import annotations

import json
import re
import sys


READ_ONLY_PREFIXES = re.compile(
    r"^\s*(?:rg|grep|find|sed|head|tail|less|cat|ls|pwd|which|whereis|"
    r"git\s+(?:status|diff|log|show|branch)|"
    r"pytest|python3?\s+-m\s+pytest|ruff|mypy)\b",
    re.IGNORECASE,
)

DESTRUCTIVE_PATTERNS = (
    re.compile(r"\brm\s+(?:-[^\s]*r[^\s]*|--recursive)\b", re.IGNORECASE),
    re.compile(r"\bgit\s+reset\s+--hard\b", re.IGNORECASE),
    re.compile(r"\bgit\s+clean\s+-[^\s]*f", re.IGNORECASE),
    re.compile(r"\bgit\s+push\b[^\n]*(?:--force(?:-with-lease)?|-f\b)", re.IGNORECASE),
    re.compile(r"\b(?:mkfs|fdisk|parted|shutdown|reboot)\b", re.IGNORECASE),
    re.compile(r"\bdd\s+[^\n]*\bof=", re.IGNORECASE),
    re.compile(r"\bdocker\s+system\s+prune\b", re.IGNORECASE),
    re.compile(r"\brsync\b[^\n]*--delete\b", re.IGNORECASE),
)

NETWORK_MUTATION = re.compile(
    r"\b(?:ip\s+(?:link|addr|route)\s+(?:set|add|del|delete)|"
    r"ifconfig\b[^\n]*\b(?:up|down)|"
    r"nmcli\b[^\n]*\b(?:modify|mod|up|down|delete)|"
    r"iptables\b|nft\s+(?:add|delete|flush))\b",
    re.IGNORECASE,
)

INDUSTRIAL_TARGET = re.compile(
    r"(?<![a-z0-9])(?:nx102|plc|clp|sysmac|robot|robo|robô|controller|controlador|"
    r"cip|ethernet\s*/?\s*ip|camera|câmera|vacuum|ventosa|safety)(?![a-z0-9])",
    re.IGNORECASE,
)

MUTATING_VERB = re.compile(
    r"(?<![a-z0-9])(?:write|set|force|upload|download|deploy|transfer|sync|flash|"
    r"firmware|start|stop|reset|restart|run|online|program|clear|ack|"
    r"output|mode|enable|disable|trigger|command)(?![a-z0-9])",
    re.IGNORECASE,
)


def decision(permission: str, reason=None) -> dict:
    result = {"permission": permission}
    if reason:
        result["user_message"] = reason
        result["agent_message"] = (
            f"A execução requer aprovação humana: {reason} "
            "Confirme alvo, backup, janela, critério de sucesso e rollback."
        )
    return result


def main() -> int:
    try:
        payload = json.load(sys.stdin)
    except (json.JSONDecodeError, UnicodeDecodeError) as exc:
        print(json.dumps(decision("deny", f"Entrada inválida no hook: {exc}"), ensure_ascii=False))
        return 0

    command = str(payload.get("command", "")).strip()
    if not command:
        print(json.dumps(decision("deny", "Comando vazio ou ausente."), ensure_ascii=False))
        return 0

    if READ_ONLY_PREFIXES.search(command) and not re.search(r"[;&|]", command):
        print(json.dumps(decision("allow"), ensure_ascii=False))
        return 0

    if any(pattern.search(command) for pattern in DESTRUCTIVE_PATTERNS):
        print(
            json.dumps(
                decision("ask", "Comando destrutivo ou difícil de reverter detectado."),
                ensure_ascii=False,
            )
        )
        return 0

    if NETWORK_MUTATION.search(command):
        print(
            json.dumps(
                decision("ask", "O comando pode alterar a configuração de rede do ambiente."),
                ensure_ascii=False,
            )
        )
        return 0

    if INDUSTRIAL_TARGET.search(command) and MUTATING_VERB.search(command):
        print(
            json.dumps(
                decision("ask", "Possível alteração de estado em equipamento ou integração industrial."),
                ensure_ascii=False,
            )
        )
        return 0

    print(json.dumps(decision("allow"), ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
